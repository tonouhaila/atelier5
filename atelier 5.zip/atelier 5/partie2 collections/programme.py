class etudiant :#on a définit une classe etudiant
    def __init__(self ,nom, prenom,age,cne,moyenne):#on a définit un constructeur
        self.nom=nom
        self.prenom=prenom
        self.age=age
        self.cne=cne
        self.moyenne=moyenne
list  = []#on a créer une liste
list.append( etudiant('ahmed', 'ALAMI', 20, 'D135', 17) )#remplir la liste à l'aide de la fonction append()
list.append( etudiant('mohamed', 'NACIRI', 21, 'D131', 19))
list.append( etudiant('nouhaila', 'nouha', 21, 'D134', 18) )
list.append( etudiant('omar', 'ELHADI', 22, 'D132', 16) )
list.append( etudiant('SIHAM', 'EL ALAMI', 19, 'D133', 15) )
list.append( etudiant('fatiha', 'el NACIRI', 20, 'D136', 14) )
print ("la liste etudiant : \n ")
for obj in list :#afficher la liste à l'aide de la boucle for
    print(obj.nom , obj.prenom ,obj.age , obj.cne , obj.moyenne ,sep=' ')
print ("la liste etudiant ordonner selon l'age : \n ")
#print(sorted(list , key= lambda etudiant: etudiant.cne))








