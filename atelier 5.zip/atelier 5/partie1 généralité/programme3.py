class Rectangle:#classe rectangle
        def __init__(self, longueur=30, largeur=15):#constructeur
                self.lon = longueur#initialiser avec des valeurs par défaut
                self.lar = largeur
                self.nom = "rectangle"

        def surface(self):#on a définie une methode surface qui va returner la surface de rectangle 
                return self.lon*self.lar
        def __str__(self):
                return ("\nLa surface du {0} de cotes {1} et {2} est  {3}"
                .format(self.nom, self.lon, self.lar, self.surface()))
class Carre(Rectangle):#classe carre hérite de la classe rectangle
        def __init__(self, cote=10):
                Rectangle.__init__(self, cote, cote)
                self.nom = "carre" 
if __name__ == '__main__': #tester le programme
        rec= Rectangle(16, 9)
        print(rec)
        car = Carre()
        print(car)
