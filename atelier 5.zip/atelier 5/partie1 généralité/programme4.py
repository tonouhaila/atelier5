class Point:#on a définie une classe Point
        def __init__(self, a=0.0, b=0.0):#un constructeur
                self.px = float(a)#on a initialiser avec des valeurs par défaut
                self.py = float(b)
class Segment:#classe composite utilisant la classe Point
        def __init__(self, A, B, C, D):#constructeur
                self.orig = Point(A, B)#on a initialisé on utiisant deux objets point
                self.extrem = Point(C, D)
        def __str__(self):
            #représentation d'un objet segment
                return ("Segment : [({0}, {1}), ({2}, {3})]".format(self.orig.px, self.orig.py, self.extrem.px, self.extrem.py))
if __name__ == '__main__':#on a ester le programme
        SEG = Segment(10, 20, 30, 40)
        print(SEG)
