
class Vecteur2D:
        def __init__(self, a=0, b=0):
                self.A = a 
                self.B = b
                self.nom = "HELLO"
        def affiche(self):
                print (self.nom)
        def __str__(self):
                
                return "A = %d, B = %d" % (self.A,self.B)

if __name__ == '__main__':
        print("Un Vecteur2D sans parametre ".center(80, '-'))
        print (Vecteur2D())
      
        print("Un Vecteur2D avec ses eux parametres ".center(80, '-'))
        print (Vecteur2D(-10.5, 9.2))
        Vecteur2D().affiche()
